package com.n1books.dev.controller;

public interface Text2SpeechDAO {
	void insertText2Speech(Text2SpeechVO vo) throws Exception;

}
